<div class="modal fade log-reg" id="loginModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
          <div class="post-tabs">
              <!-- tab navs -->
              <ul class="nav nav-tabs nav-pills nav-fill" id="postsTab" role="tablist">
                  <li class="nav-item" role="presentation">
                      <button aria-controls="login" aria-selected="false" class="nav-link active" data-bs-target="#login" data-bs-toggle="tab" id="login-tab" role="tab" type="button">Login</button>
                  </li>
                  <li class="nav-item" role="presentation">
                      <button aria-controls="register" aria-selected="true" class="nav-link" data-bs-target="#register" data-bs-toggle="tab" id="register-tab" role="tab" type="button">Register</button>
                  </li>
              </ul>
              <!-- tab contents -->
              <div class="tab-content blog-full" id="postsTabContent">
                  <!-- popular posts -->
                  <div aria-labelledby="login-tab" class="tab-pane fade active show" id="login" role="tabpanel">
                    <?php if (isset($component)) { $__componentOriginalea38cd717900d7584fb0ccf9f737edff43863de1 = $component; } ?>
<?php $component = App\View\Components\Auth\Login::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth.login'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Auth\Login::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalea38cd717900d7584fb0ccf9f737edff43863de1)): ?>
<?php $component = $__componentOriginalea38cd717900d7584fb0ccf9f737edff43863de1; ?>
<?php unset($__componentOriginalea38cd717900d7584fb0ccf9f737edff43863de1); ?>
<?php endif; ?>
                  </div>
                  <!-- Recent posts -->
                  <div aria-labelledby="register-tab" class="tab-pane fade" id="register" role="tabpanel">
                    <?php if (isset($component)) { $__componentOriginalf052ebec929503087c2a1872c9dd21918d74733a = $component; } ?>
<?php $component = App\View\Components\Auth\Register::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth.register'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Auth\Register::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf052ebec929503087c2a1872c9dd21918d74733a)): ?>
<?php $component = $__componentOriginalf052ebec929503087c2a1872c9dd21918d74733a; ?>
<?php unset($__componentOriginalf052ebec929503087c2a1872c9dd21918d74733a); ?>
<?php endif; ?>
                  </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php /**PATH /home/hamdani/code/e-ticket/resources/views/components/shared/login-register.blade.php ENDPATH**/ ?>