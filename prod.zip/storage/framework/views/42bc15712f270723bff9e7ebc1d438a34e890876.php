<div class="col-lg-4">
    <div class="sidebar-sticky">
        <div class="list-sidebar">

            <div class="sidebar-item mb-4">
                <ul class="sidebar-category">
                    <li class="<?php echo e(Route::current()->getName() == 'user.order' ? 'active': ''); ?>">
                        <a href="<?php echo e(route('user.order')); ?>">
                            <i class="fas fa-shopping-cart"></i> Order
                        </a>
                    </li>
                    <li class="<?php echo e(Route::current()->getName() == 'user.setting' ? 'active': ''); ?>">
                        <a href="<?php echo e(route('user.setting')); ?>">
                            <i class="fas fa-cog"></i> Pengaturan
                        </a>
                    </li>
                    <li class="<?php echo e(Route::current()->getName() == 'user.message' ? 'active': ''); ?>">
                        <a href="<?php echo e(route('user.message')); ?>">
                            <i class="fas fa-envelope"></i> Pesan
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/hamdani/code/e-ticket/resources/views/components/user/sidebar.blade.php ENDPATH**/ ?>