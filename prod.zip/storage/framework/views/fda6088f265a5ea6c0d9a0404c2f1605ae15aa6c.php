<?php if (isset($component)) { $__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f = $component; } ?>
<?php $component = App\View\Components\Layouts\Main::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layouts\Main::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Book your ticket
     <?php $__env->endSlot(); ?>
    <section class="trending pt-6 pb-0 bg-lgrey">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mb-4">
                    <div class="payment-book">
                        <form class="booking-box needs-validation" data-parsley-validate data-parsley-errors-messages-disabled action="<?php echo e(route('booking.confirm')); ?>" method="post" novalidate>
                            <div class="customer-information mb-4">
                                <h3 class="border-b pb-2 mb-2">Informasi Pemumpang (<?php echo e($bookingType === 'quantity' ? 'Quantity': $bookingPacket); ?>)</h3>
                                <div class="mb-2">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="destinationId" value="<?php echo e($destination->id); ?>">
                                    <input type="hidden" name="userId" value="1">
                                    <input type="hidden" name="scheduleId" value="<?php echo e($bookingTime); ?>">
                                    <input type="hidden" name="date" value="<?php echo e($bookingDate); ?>">
                                    <input type="hidden" name="status" value="pending">
                                    <input type="hidden" name="type" value="<?php echo e($bookingType === 'quantity' ? 'quantity' : $bookingPacket); ?>">
                                    <?php if($bookingType == 'quantity'): ?>
                                        <?php for($i = 0; $i <= (int)$ticketQuantity - 1; $i++): ?>
                                        <h5>Penumpang <?php echo e($i+1); ?></h5>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group mb-2">
                                                    <label>NIK</label>
                                                    <input type="text" name="nik[<?php echo e($i); ?>]" placeholder="NIK" class="form-control" required/>
                                                    <div class="invalid-feedback">
                                                        NIK tidak boleh kosong
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group mb-2">
                                                    <label>Nama</label>
                                                    <input type="text" name="name[<?php echo e($i); ?>]" placeholder="Nama Lengkap" class="form-control" required/>
                                                    <div class="invalid-feedback">
                                                        Nama tidak boleh kosong
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group mb-2">
                                                    <label>Email</label>
                                                    <input type="text" name="email[<?php echo e($i); ?>]" placeholder="Email" class="form-control" required/>
                                                    <div class="invalid-feedback">
                                                        Email tidak boleh kosong
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endfor; ?>
                                    <?php elseif($bookingType === 'paket' && $bookingPacket === 'couple'): ?>
                                        <h5>Penumpang 1</h5>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group mb-2">
                                                    <label>NIK</label>
                                                    <input type="text" name="nik[0]" placeholder="NIK" class="form-control" required/>
                                                    <div class="invalid-feedback">
                                                        NIK tidak boleh kosong
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group mb-2">
                                                    <label>Nama</label>
                                                    <input type="text" name="name[0]" placeholder="Nama Lengkap" class="form-control" required/>
                                                    <div class="invalid-feedback">
                                                        Nama tidak boleh kosong
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group mb-2">
                                                    <label>Email</label>
                                                    <input type="text" name="email[0]" placeholder="Email" class="form-control" required/>
                                                    <div class="invalid-feedback">
                                                        Email tidak boleh kosong
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <h5>Penumpang 2</h5>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group mb-2">
                                                    <label>NIK</label>
                                                    <input type="text" name="nik[1]" placeholder="NIK" class="form-control" required/>
                                                    <div class="invalid-feedback">
                                                        NIK tidak boleh kosong
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group mb-2">
                                                    <label>Nama</label>
                                                    <input type="text" name="name[1] placeholder="Nama Lengkap" class="form-control" required/>
                                                    <div class="invalid-feedback">
                                                        Nama tidak boleh kosong
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group mb-2">
                                                    <label>Email</label>
                                                    <input type="text" name="email[1]" placeholder="Email" class="form-control" required/>
                                                    <div class="invalid-feedback">
                                                        Email tidak boleh kosong
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php elseif($bookingType === 'paket' && $bookingPacket === 'family'): ?>
                                        <?php for($i = 0; $i < (int)$familyCount; $i++): ?>
                                        <h5>Anggota Keluarga <?php echo e($i+1); ?> </h5>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="form-group mb-2">
                                                        <label>NIK</label>
                                                        <input type="text" name="nik[<?php echo e($i); ?>]" placeholder="NIK" class="form-control" required/>
                                                        <div class="invalid-feedback">
                                                            NIK tidak boleh kosong
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group mb-2">
                                                        <label>Nama</label>
                                                        <input type="text" name="name[<?php echo e($i); ?>]" placeholder="Nama Lengkap" class="form-control" required/>
                                                        <div class="invalid-feedback">
                                                            Nama tidak boleh kosong
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group mb-2">
                                                        <label>Email</label>
                                                        <input type="text" name="email[<?php echo e($i); ?>]" placeholder="Email" class="form-control" required/>
                                                        <div class="invalid-feedback">
                                                            Email tidak boleh kosong
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endfor; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="customer-information mb-4 d-flex align-items-center bg-grey rounded p-4">
                                <i class="fa fa-grin-wink rounded fs-1 bg-theme white p-3 px-4"></i>
                                <div class="customer-info ps-4">
                                    <h6 class="mb-1">Good To Know:</h6>
                                    <small>Beberapa informasi berguna untuk penumpang</small>
                                </div>
                            </div>
                            <div class="customer-information card-information">
                                <div class="booking-terms border-t pt-3 mt-3">
                                    <button class="nir-btn float-lg-star w-100"  type="submit">Checkout</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="col-lg-4 mb-4 ps-ld-4">
                    <?php if($bookingType == 'quantity'): ?>
                    <?php if (isset($component)) { $__componentOriginal188661906bad31621be284fc13e93a65ef837fee = $component; } ?>
<?php $component = App\View\Components\Shared\BookingSidebar::resolve(['destination' => $destination,'quantity' => $ticketQuantity,'date' => $bookingDate,'time' => $bookingTime] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.booking-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Shared\BookingSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal188661906bad31621be284fc13e93a65ef837fee)): ?>
<?php $component = $__componentOriginal188661906bad31621be284fc13e93a65ef837fee; ?>
<?php unset($__componentOriginal188661906bad31621be284fc13e93a65ef837fee); ?>
<?php endif; ?>
                    <?php elseif($bookingType === 'paket' && $bookingPacket === 'couple'): ?>
                    <?php if (isset($component)) { $__componentOriginal188661906bad31621be284fc13e93a65ef837fee = $component; } ?>
<?php $component = App\View\Components\Shared\BookingSidebar::resolve(['destination' => $destination,'quantity' => '1','date' => $bookingDate,'time' => $bookingTime,'packet' => 'couple'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.booking-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Shared\BookingSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal188661906bad31621be284fc13e93a65ef837fee)): ?>
<?php $component = $__componentOriginal188661906bad31621be284fc13e93a65ef837fee; ?>
<?php unset($__componentOriginal188661906bad31621be284fc13e93a65ef837fee); ?>
<?php endif; ?>
                    <?php elseif($bookingType === 'paket' && $bookingPacket === 'family'): ?>
                    <?php if (isset($component)) { $__componentOriginal188661906bad31621be284fc13e93a65ef837fee = $component; } ?>
<?php $component = App\View\Components\Shared\BookingSidebar::resolve(['destination' => $destination,'quantity' => $familyCount,'date' => $bookingDate,'time' => $bookingTime,'packet' => 'family'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.booking-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Shared\BookingSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal188661906bad31621be284fc13e93a65ef837fee)): ?>
<?php $component = $__componentOriginal188661906bad31621be284fc13e93a65ef837fee; ?>
<?php unset($__componentOriginal188661906bad31621be284fc13e93a65ef837fee); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('assets/js/parsleyjs/parsley.min.js')); ?>"></script>

        <script>
            
            
            
            
            $(document).ready(function () {
                $('#checkOutButton').on('click', function (e) {
                    var parsley = $('.needs-validation').parsley({
                        errorClass: 'is-invalid',
                        successClass: 'is-valid'
                    })

                    parsley.validate()

                    if(parsley.isValid()) {
                        $('.needs-validation').submit();
                    }

                });
            })
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f)): ?>
<?php $component = $__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f; ?>
<?php unset($__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f); ?>
<?php endif; ?>
<?php /**PATH /home/hamdani/code/e-ticket/resources/views/booking.blade.php ENDPATH**/ ?>